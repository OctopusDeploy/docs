﻿cd "C:\Program Files\Octopus Deploy\Tentacle"

function Delete-Tentacle ([string] $instance) {
    Write-Verbose "Deleting the Tentacle $instance"

    .\Tentacle.exe service --instance $instance --stop --uninstall
    .\Tentacle.exe delete-instance --instance $instance
}


$machineName = $OctopusParameters['Octopus.Machine.Name']
Delete-Tentacle $machineName